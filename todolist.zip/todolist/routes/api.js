const express = require('express')
const bodyParser = require('body-parser');
const tasks = require('../model/tasks')
const router = express.Router();

router.get('/all', (req, res)=>{
    res.json(JSON.stringify(tasks.getAll()))
})

router.post('/new', bodyParser.json(), (req, res) =>{
    let name = req.body.name;
    let description = req.body.description;
    let status = req.body.status;

    tasks.newTask(name, description, status)

    res.send("Tarefa adicionada")
})

router.delete('/del', bodyParser.json(), (req, res)=>{
    let id = req.body.id;
    tasks.deleteTask(id)

    res.send("Tarefa deletada")
})

router.put('/update', bodyParser.json(), (req, res)=>{
    let id = req.body.id;
    let status = req.body.status;

    tasks.updateStatus(id, status)

    res.send("Status atualizado")
})

module.exports = router;