function ActiveDragDrop(){
    const cards = document.querySelectorAll('.card')
    const dropzones = document.querySelectorAll('.dropzone')
    const deletezone = document.querySelector('.delete')

    cards.forEach(card=>{
        card.addEventListener('dragstart', dragstart)
        card.addEventListener('drag', drag)
        card.addEventListener('dragend', dragend)
    })

    function dragstart(){
        this.classList.add('is-draging')
    }

    function drag(){
        
    }

    function dragend(){
        updateTaskStatus()
        this.classList.remove('is-draging')
    }

    dropzones.forEach(dropzone=>{
        dropzone.addEventListener('dragenter', dragenter)
        dropzone.addEventListener('dragover', dragover)
        dropzone.addEventListener('dragleave', dragleave)
        dropzone.addEventListener('drop', drop)
    })

    function dragenter(){

    }

    function dragover(){
        this.classList.add('over')
        const cardBeingDragged = document.querySelector('.is-draging')
        this.appendChild(cardBeingDragged)
        
    }

    function dragleave(){
        this.classList.remove('over')
        const cardBeingDragged = document.querySelector('.is-draging')
       
    }

    function drop(){
        this.classList.remove('over')
        
    }

    deletezone.addEventListener('dragenter', dragenterDel)
    deletezone.addEventListener('dragover', dragoverDel)
    deletezone.addEventListener('dragleave', dragleaveDel)
    deletezone.addEventListener('drop', dropDel)

    function dragenterDel(){

    }

    function dragoverDel(){
        this.classList.add('over')
        const cardBeingDragged = document.querySelector('.is-draging')
        this.appendChild(cardBeingDragged)
        this.removeChild(cardBeingDragged);

        removeTask(cardBeingDragged.id)
    }

    function dragleaveDel(){
        this.classList.remove('over')
    }

    function dropDel(){
        this.classList.remove('over')
    }
}