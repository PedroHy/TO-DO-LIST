
document.addEventListener('DOMContentLoaded', ()=>{
    getTasks();
})

function getTasks(){
    const getURL = 'http://localhost:3000/api/all'

    fetch(getURL).then(res=>{
        return res.json();
    }).then(json=>{
        let listToDo = ''
        let listInProgress = ''
        let listDone = ''
        let tasks = JSON.parse(json)

        tasks.forEach(task => {
            let item = `<div class="card" draggable="true" id=${task.id}>
                            <div class="name">${task.name}</div>
                            <div class="description">${task.description}</div>
                        </div>`
            switch(task.status){
                case "todo":
                    listToDo += item;
                    break;
                case "in-progress":
                    listInProgress += item;
                    break;
                case "done":
                    listDone += item;
                    break;
            }
        });

        document.querySelector("#todo").innerHTML = listToDo;
        document.querySelector("#in-progress").innerHTML = listInProgress;
        document.querySelector("#done").innerHTML = listDone;
        ActiveDragDrop();
    })
    
}

function addTask(){
    let name = document.querySelector('#name-input').value
    let description = document.querySelector('#desc-input').value
    let status = "todo"
    let task = {name, description, status}

    console.log(name, description, status)
    console.log(task)
    const postURL = 'http://localhost:3000/api/new'
    const options = {
                        method: 'POST',
                        headers: {'Content-Type': 'application/json'},
                        body: JSON.stringify(task)
                    }

    fetch(postURL, options).then((res)=>{
        getTasks();
    }).catch((err) => console.log(err));

    clearFields();
}

function removeTask(id){
    const deleteURL = 'http://localhost:3000/api/del'
    const options = {
        method: 'DELETE',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({id})
    }

    fetch(deleteURL, options).then(()=>{
        getTasks();
    }).catch((err) => console.log(err));
}

function updateTaskStatus(){
    let cards = document.querySelectorAll(".card")
    cards.forEach(card =>{
        let status = card.parentNode.id
        let id = card.id
        console.log(status)
        
        const putURL = 'http://localhost:3000/api/update'
        const options = {
                            method: 'PUT',
                            headers: {'Content-Type': 'application/json'},
                            body: JSON.stringify({id, status})
                        }

        fetch(putURL, options).then(()=>{
            console.log("dados atualizados")
            getTasks();
        }).catch((err) => console.log(err));
    })

    
    /*
    const putURL = 'http://localhost:3000/api/update'
    const options = {
        method: 'PUT',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({id, status})
    }

    fetch(putURL, options).then(()=>{
        console.log("dados atualizados")
        getTasks();
    }).catch((err) => console.log(err));
*/
}

function clearFields(){
    let name = document.querySelector('#name-input').value = ''
    let description = document.querySelector('#desc-input').value = ''
}

