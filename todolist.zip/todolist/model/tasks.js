module.exports = {
    tasks: [
       
    ],
    
    getAll(){
        return this.tasks
    },

    newTask(name, description, status){
        this.tasks.push({id: generateId(), name, description, status})
    },

    deleteTask(id){
        let index;
        this.tasks.forEach(task=>{
            if(task.id == id){
                index = this.tasks.indexOf(task)
            }
        })

        this.tasks.splice(index, 1);
    },

    updateStatus(id, status){
        
        this.tasks.forEach(task=>{
            if(task.id == id){
                task.status = status;
            }
        })
    }
}

function generateId(){
    return Math.random().toString(36).substring(2, 9);
}