//modulos
const express = require('express')
const path = require('path')

const api = require('./routes/api')
const app = express();


//routes
app.use('/', express.static(path.join(__dirname, 'public')))
app.use('/api/', api)


//opening server
const PORT = 3000;
app.listen(PORT, ()=>{     
    console.log("Server runing on port", PORT);
})